package com.hartor.app.stepDefinitions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import javax.lang.model.element.Name;

public class contactStepDefinitions {

    public contactStepDefinitions() {
    }

    @Given("^que estoy en la página de contacto$")
    public void prepararvalidacion() {

    }


    @When("^completo el campo de nombre con \"([^\"]*)\" Y lleno el campo de correo electrónico con \"([^\"]*)\"$")
    public void validando(String arg1, String arg2) {


    }

    @Then("^el nombre del campo no debe estar vacío y el campo de correo electrónico no debe estar vacío$")
    public void resultado() {


    }

}
